#include <linux/module.h>    // included for all kernel modules
#include <linux/kernel.h>    // included for KERN_INFO
#include <linux/init.h>      // included for __init and __exit macros

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Urban, Scattolin");
MODULE_DESCRIPTION("Get the contents of control register 4");

static int __init cr4_init(void)
{
    unsigned long long result;
    __asm__("movq %%cr4, %%rax\n" : "=a"(result));
    printk(KERN_INFO "cr4 holds: %llu\n", result);
    return 0;    // Non-zero return means that the module couldn't be loaded.
}

static void __exit cr4_cleanup(void)
{
    printk(KERN_INFO "Cleaning up module.\n");
}

module_init(cr4_init);
module_exit(cr4_cleanup);
